package com.example.debtbook.data

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var countryIso: String?
        get() = sp.getString("country_iso", null)
        set(v) = sp.edit().putString("country_iso", v).apply()

    var currencyCode: String?
        get() = sp.getString("currency_code", null)
        set(v) = sp.edit().putString("currency_code", v).apply()
}
