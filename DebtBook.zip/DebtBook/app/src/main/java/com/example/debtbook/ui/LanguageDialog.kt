package com.example.debtbook.ui

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.os.LocaleListCompat
import com.example.debtbook.R

@Composable
fun LanguageDialog(onDismiss: () -> Unit) {
    val options = listOf(
        "" to stringResource(R.string.system_default),
        "ar" to "العربية",
        "en" to "English",
        "fr" to "Français"
    )
    val current = AppCompatDelegate.getApplicationLocales()
        .toLanguageTags().substringBefore(',').substringBefore('-')

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AppColors.SurfaceHigh,
        title = { Text(stringResource(R.string.language), color = AppColors.TextPrimary) },
        text = {
            Column {
                options.forEach { (tag, label) ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable {
                                AppCompatDelegate.setApplicationLocales(
                                    if (tag.isEmpty()) LocaleListCompat.getEmptyLocaleList()
                                    else LocaleListCompat.forLanguageTags(tag)
                                )
                                onDismiss()
                            }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = current == tag, onClick = null)
                        Spacer(Modifier.width(12.dp))
                        Text(label, color = AppColors.TextPrimary)
                    }
                }
            }
        },
        confirmButton = {}
    )
}
