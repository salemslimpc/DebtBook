package com.example.debtbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.debtbook.R
import com.example.debtbook.data.CountryOption
import com.example.debtbook.data.Countries
import java.util.Locale

/** First-run screen (and "change country" screen): the country decides the default currency. */
@Composable
fun CountryScreen(
    initialIso: String?,
    onBack: (() -> Unit)?,
    onConfirm: (CountryOption) -> Unit
) {
    val all = remember { Countries.list() }
    var query by remember { mutableStateOf("") }
    var selectedIso by remember {
        mutableStateOf(initialIso ?: Locale.getDefault().country.takeIf { c -> all.any { it.iso == c } })
    }
    val filtered = remember(query, all) {
        val q = query.trim()
        if (q.isEmpty()) all else all.filter {
            it.name.contains(q, ignoreCase = true) ||
                it.currencyCode.contains(q, ignoreCase = true) ||
                it.currencyName.contains(q, ignoreCase = true)
        }
    }

    Box(Modifier.fillMaxSize().background(AppColors.Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(16.dp))
            if (onBack != null) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(AppColors.Surface)
                        .clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppColors.TextPrimary)
                }
                Spacer(Modifier.height(16.dp))
            }
            Text(
                stringResource(R.string.country_title),
                color = AppColors.TextPrimary,
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(Modifier.height(4.dp))
            Text(
                stringResource(R.string.country_subtitle),
                color = AppColors.TextSecondary,
                fontSize = 14.sp
            )
            Spacer(Modifier.height(16.dp))
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text(stringResource(R.string.country_search)) },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                singleLine = true,
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (filtered.isEmpty()) {
                    item {
                        Text(
                            stringResource(R.string.no_results),
                            color = AppColors.TextSecondary,
                            modifier = Modifier.padding(vertical = 24.dp)
                        )
                    }
                }
                items(filtered, key = { it.iso }) { c ->
                    CountryRow(c, c.iso == selectedIso) { selectedIso = c.iso }
                }
            }

            val canContinue = selectedIso != null
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
                    .navigationBarsPadding()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (canContinue) AppColors.HeroBrush
                        else Brush.linearGradient(listOf(Color(0xFF2A3150), Color(0xFF2A3150)))
                    )
                    .clickable(enabled = canContinue) {
                        all.firstOrNull { it.iso == selectedIso }?.let(onConfirm)
                    }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    stringResource(R.string.continue_btn),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
private fun CountryRow(c: CountryOption, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected) AppColors.Violet.copy(alpha = 0.28f) else AppColors.Surface)
            .border(1.dp, if (selected) AppColors.Violet else AppColors.Border, shape)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(Countries.flagEmoji(c.iso), fontSize = 28.sp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.name, color = AppColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
            Text(
                "${c.currencyName} (${c.currencyCode})",
                color = AppColors.TextSecondary,
                fontSize = 12.sp
            )
        }
        if (selected) Icon(Icons.Filled.Check, null, tint = AppColors.Mint)
    }
}
