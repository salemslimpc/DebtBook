package com.example.debtbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.debtbook.DebtItem
import com.example.debtbook.PersonSummary
import com.example.debtbook.R
import androidx.compose.ui.res.stringResource
import com.example.debtbook.data.Debt

@Composable
fun PersonScreen(
    summary: PersonSummary,
    onBack: () -> Unit,
    onAddPayment: (debtId: Long, amount: Double) -> Unit,
    onDeleteDebt: (Debt) -> Unit
) {
    var payFor by remember { mutableStateOf<DebtItem?>(null) }
    val net = summary.net

    Box(Modifier.fillMaxSize().background(AppColors.Bg)) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(AppColors.Surface)
                            .clickable(onClick = onBack),
                        contentAlignment = Alignment.Center
                    ) {
                        // السهم يعكس اتجاهه تلقائياً في RTL
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = AppColors.TextPrimary)
                    }
                }
            }
            item {
                Column(
                    Modifier.fillMaxWidth().padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Avatar(summary.person.name, size = 84.dp)
                    Spacer(Modifier.height(12.dp))
                    Text(
                        summary.person.name,
                        color = AppColors.TextPrimary,
                        style = MaterialTheme.typography.headlineMedium
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        money(net),
                        color = if (net == 0.0) AppColors.TextSecondary
                        else if (net > 0) AppColors.Mint else AppColors.Coral,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        if (net == 0.0) stringResource(R.string.no_pending)
                        else if (net > 0) stringResource(R.string.they_owe_you)
                        else stringResource(R.string.you_owe_him),
                        color = AppColors.TextSecondary,
                        fontSize = 13.sp
                    )
                }
            }
            items(summary.debts, key = { it.debt.id }) { item ->
                DebtCard(item, onPay = { payFor = item }, onDelete = { onDeleteDebt(item.debt) })
            }
        }
    }

    payFor?.let { item ->
        PaymentDialog(
            remaining = item.remaining,
            onDismiss = { payFor = null },
            onConfirm = { amount ->
                onAddPayment(item.debt.id, amount)
                payFor = null
            }
        )
    }
}

@Composable
private fun DebtCard(item: DebtItem, onPay: () -> Unit, onDelete: () -> Unit) {
    val mine = item.debt.isOwedToMe
    val brush = if (mine) AppColors.MintBrush else AppColors.CoralBrush
    val color = if (mine) AppColors.Mint else AppColors.Coral

    Column(Modifier.fillMaxWidth().glassCard(24.dp).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    if (mine) stringResource(R.string.debt_to_me) else stringResource(R.string.debt_i_owe),
                    color = color,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Text(
                    money(item.debt.amount),
                    color = AppColors.TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp
                )
            }
            Icon(
                Icons.Filled.Delete,
                null,
                tint = AppColors.TextSecondary,
                modifier = Modifier.size(22.dp).clickable(onClick = onDelete)
            )
        }
        if (item.debt.note.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text(item.debt.note, color = AppColors.TextSecondary, fontSize = 13.sp)
        }
        Spacer(Modifier.height(14.dp))
        ProgressPill(item.progress, brush)
        Spacer(Modifier.height(8.dp))
        Row {
            Text(
                stringResource(R.string.paid_amount, money(item.paid)),
                color = AppColors.TextSecondary,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            Text(
                if (item.isSettled) stringResource(R.string.settled_check)
                else stringResource(R.string.remaining_amount, money(item.remaining)),
                color = if (item.isSettled) AppColors.Mint else AppColors.TextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        Spacer(Modifier.height(6.dp))
        val dateOn = stringResource(R.string.date_on, formatDate(item.debt.createdAt))
        val dueOn = item.debt.dueDate?.let { stringResource(R.string.due_on, formatDate(it)) }
        Text(
            if (dueOn != null) "$dateOn • $dueOn" else dateOn,
            color = AppColors.TextSecondary,
            fontSize = 11.sp
        )
        if (!item.isSettled) {
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x14FFFFFF))
                    .clickable(onClick = onPay)
                    .padding(vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(stringResource(R.string.record_payment), color = AppColors.TextPrimary, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun PaymentDialog(remaining: Double, onDismiss: () -> Unit, onConfirm: (Double) -> Unit) {
    var text by remember { mutableStateOf("") }
    val value = text.replace(',', '.').toDoubleOrNull()
    val valid = value != null && value > 0 && value <= remaining + 0.0001

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AppColors.SurfaceHigh,
        title = { Text(stringResource(R.string.record_payment), color = AppColors.TextPrimary) },
        text = {
            Column {
                Text(stringResource(R.string.remaining_colon, money(remaining)), color = AppColors.TextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text(stringResource(R.string.amount)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
                )
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onConfirm(value!!) }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}
