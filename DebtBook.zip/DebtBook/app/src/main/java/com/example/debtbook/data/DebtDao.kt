package com.example.debtbook.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface DebtDao {
    @Query("SELECT * FROM persons ORDER BY name")
    fun observePersons(): Flow<List<Person>>

    @Query("SELECT * FROM debts ORDER BY createdAt DESC")
    fun observeDebts(): Flow<List<Debt>>

    @Query("SELECT * FROM payments ORDER BY paidAt DESC")
    fun observePayments(): Flow<List<Payment>>

    @Query("SELECT * FROM persons WHERE name = :name LIMIT 1")
    suspend fun findPerson(name: String): Person?

    @Insert
    suspend fun insertPerson(person: Person): Long

    @Insert
    suspend fun insertDebt(debt: Debt): Long

    @Insert
    suspend fun insertPayment(payment: Payment): Long

    @Delete
    suspend fun deleteDebt(debt: Debt)

    @Delete
    suspend fun deletePerson(person: Person)
}
