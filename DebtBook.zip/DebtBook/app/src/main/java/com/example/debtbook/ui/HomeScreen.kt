package com.example.debtbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.debtbook.HomeState
import com.example.debtbook.PersonSummary
import com.example.debtbook.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.navigationBarsPadding

@Composable
fun HomeScreen(
    state: HomeState,
    onPersonClick: (Long) -> Unit,
    onAddClick: () -> Unit,
    onLanguageClick: () -> Unit,
    onCountryClick: () -> Unit,
    showAds: Boolean
) {
    Box(Modifier.fillMaxSize().background(AppColors.Bg)) {
        // توهّج لوني خفيف في الخلفية
        Box(
            Modifier
                .fillMaxWidth()
                .height(360.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(AppColors.Violet.copy(alpha = 0.28f), Color.Transparent)
                    )
                )
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 16.dp, bottom = if (showAds) 210.dp else 130.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Header(onLanguageClick, onCountryClick) }
            item { HeroBalance(state) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    MiniStat(
                        modifier = Modifier.weight(1f),
                        title = stringResource(R.string.owed_to_me),
                        amount = state.totalOwedToMe,
                        brush = AppColors.MintBrush,
                        up = false
                    )
                    MiniStat(
                        modifier = Modifier.weight(1f),
                        title = stringResource(R.string.i_owe),
                        amount = state.totalIOwe,
                        brush = AppColors.CoralBrush,
                        up = true
                    )
                }
            }
            item {
                Text(
                    stringResource(R.string.people),
                    style = MaterialTheme.typography.titleLarge,
                    color = AppColors.TextPrimary,
                    modifier = Modifier.padding(top = 10.dp)
                )
            }
            if (state.people.isEmpty()) {
                item { EmptyState() }
            } else {
                items(state.people, key = { it.person.id }) { p ->
                    PersonRow(p) { onPersonClick(p.person.id) }
                }
            }
        }

        AddButton(
            onClick = onAddClick,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = if (showAds) 76.dp else 24.dp)
        )

        if (showAds) {
            AdBanner(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .background(AppColors.Bg)
                    .navigationBarsPadding()
            )
        }
    }
}

@Composable
private fun Header(onLanguageClick: () -> Unit, onCountryClick: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(stringResource(R.string.greeting), color = AppColors.TextSecondary, fontSize = 14.sp)
            Text(
                stringResource(R.string.app_name),
                color = AppColors.TextPrimary,
                style = MaterialTheme.typography.headlineMedium
            )
        }
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(AppColors.Surface)
                .clickable(onClick = onCountryClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Public, null, tint = AppColors.Mint)
        }
        Spacer(Modifier.width(8.dp))
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(AppColors.Surface)
                .clickable(onClick = onLanguageClick),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Language, null, tint = AppColors.Cyan)
        }
    }
}

@Composable
private fun HeroBalance(state: HomeState) {
    val net = state.net
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(AppColors.HeroBrush)
            .padding(24.dp)
    ) {
        Column {
            Text(stringResource(R.string.net_balance), color = Color.White.copy(alpha = 0.8f), fontSize = 14.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                text = (if (net < 0) "-" else "") + money(net),
                color = Color.White,
                style = MaterialTheme.typography.displayLarge
            )
            Spacer(Modifier.height(10.dp))
            Text(
                text = when {
                    net > 0 -> stringResource(R.string.net_positive)
                    net < 0 -> stringResource(R.string.net_negative)
                    else -> stringResource(R.string.net_zero)
                },
                color = Color.White.copy(alpha = 0.85f),
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun MiniStat(
    modifier: Modifier,
    title: String,
    amount: Double,
    brush: Brush,
    up: Boolean
) {
    Column(modifier.glassCard(24.dp).padding(16.dp)) {
        Box(
            Modifier.size(36.dp).clip(RoundedCornerShape(12.dp)).background(brush),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (up) Icons.Filled.ArrowUpward else Icons.Filled.ArrowDownward,
                null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(Modifier.height(12.dp))
        Text(title, color = AppColors.TextSecondary, fontSize = 13.sp)
        Text(
            money(amount),
            color = AppColors.TextPrimary,
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp
        )
    }
}

@Composable
private fun PersonRow(p: PersonSummary, onClick: () -> Unit) {
    val net = p.net
    val owedToMe = net >= 0
    Row(
        Modifier
            .fillMaxWidth()
            .glassCard(24.dp)
            .clickable(onClick = onClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Avatar(p.person.name)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                p.person.name,
                color = AppColors.TextPrimary,
                style = MaterialTheme.typography.titleMedium
            )
            val open = p.debts.count { !it.isSettled }
            Text(
                if (open == 0) stringResource(R.string.settled_fully) else stringResource(R.string.active_debts, open),
                color = AppColors.TextSecondary,
                fontSize = 12.sp
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                money(net),
                color = if (net == 0.0) AppColors.TextSecondary
                else if (owedToMe) AppColors.Mint else AppColors.Coral,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                if (net == 0.0) "" else if (owedToMe) stringResource(R.string.they_owe_you) else stringResource(R.string.you_owe),
                color = AppColors.TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("📒", fontSize = 48.sp)
        Spacer(Modifier.height(10.dp))
        Text(stringResource(R.string.no_debts), color = AppColors.TextPrimary, style = MaterialTheme.typography.titleMedium)
        Text(stringResource(R.string.no_debts_hint), color = AppColors.TextSecondary, fontSize = 13.sp)
    }
}

@Composable
private fun AddButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(AppColors.HeroBrush)
            .clickable(onClick = onClick)
            .padding(horizontal = 28.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Add, null, tint = Color.White)
        Spacer(Modifier.width(8.dp))
        Text(stringResource(R.string.add_debt), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}
