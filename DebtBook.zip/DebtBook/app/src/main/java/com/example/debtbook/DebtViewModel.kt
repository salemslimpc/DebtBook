package com.example.debtbook

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.debtbook.data.AppDatabase
import com.example.debtbook.data.Debt
import com.example.debtbook.data.Payment
import com.example.debtbook.data.Person
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DebtItem(
    val debt: Debt,
    val payments: List<Payment>
) {
    val paid: Double get() = payments.sumOf { it.amount }
    val remaining: Double get() = (debt.amount - paid).coerceAtLeast(0.0)
    val progress: Float get() = if (debt.amount <= 0) 1f else (paid / debt.amount).toFloat().coerceIn(0f, 1f)
    val isSettled: Boolean get() = remaining <= 0.0
}

data class PersonSummary(
    val person: Person,
    val debts: List<DebtItem>
) {
    /** موجب: الشخص مدين لي. سالب: أنا مدين له. */
    val net: Double
        get() = debts.sumOf { if (it.debt.isOwedToMe) it.remaining else -it.remaining }
}

data class HomeState(
    val people: List<PersonSummary> = emptyList(),
    val totalOwedToMe: Double = 0.0,
    val totalIOwe: Double = 0.0
) {
    val net: Double get() = totalOwedToMe - totalIOwe
}

class DebtViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()

    val state: StateFlow<HomeState> = combine(
        dao.observePersons(),
        dao.observeDebts(),
        dao.observePayments()
    ) { persons, debts, payments ->
        val paymentsByDebt = payments.groupBy { it.debtId }
        val debtsByPerson = debts.groupBy { it.personId }
        val summaries = persons.map { p ->
            PersonSummary(
                person = p,
                debts = (debtsByPerson[p.id] ?: emptyList())
                    .map { DebtItem(it, paymentsByDebt[it.id] ?: emptyList()) }
            )
        }.filter { it.debts.isNotEmpty() }
            .sortedByDescending { kotlin.math.abs(it.net) }

        val allItems = summaries.flatMap { it.debts }
        HomeState(
            people = summaries,
            totalOwedToMe = allItems.filter { it.debt.isOwedToMe }.sumOf { it.remaining },
            totalIOwe = allItems.filter { !it.debt.isOwedToMe }.sumOf { it.remaining }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HomeState())

    fun addDebt(
        name: String,
        amount: Double,
        isOwedToMe: Boolean,
        note: String,
        dueDate: Long?
    ) {
        viewModelScope.launch {
            val clean = name.trim()
            val personId = dao.findPerson(clean)?.id ?: dao.insertPerson(Person(name = clean))
            dao.insertDebt(
                Debt(
                    personId = personId,
                    amount = amount,
                    isOwedToMe = isOwedToMe,
                    note = note.trim(),
                    dueDate = dueDate
                )
            )
        }
    }

    fun addPayment(debtId: Long, amount: Double) {
        viewModelScope.launch { dao.insertPayment(Payment(debtId = debtId, amount = amount)) }
    }

    fun deleteDebt(debt: Debt) {
        viewModelScope.launch { dao.deleteDebt(debt) }
    }

    fun deletePerson(person: Person) {
        viewModelScope.launch { dao.deletePerson(person) }
    }
}
