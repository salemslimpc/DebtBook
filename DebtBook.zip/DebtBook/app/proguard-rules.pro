# Room and Compose work with the default rules.
