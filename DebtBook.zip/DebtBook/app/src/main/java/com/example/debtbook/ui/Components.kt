package com.example.debtbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.compositionLocalOf
import com.example.debtbook.data.CurrencyInfo
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The currency of the country chosen at first launch. */
val LocalCurrency = compositionLocalOf { CurrencyInfo("USD", "$", 2) }

fun formatAmount(value: Double, currency: CurrencyInfo): String {
    val abs = kotlin.math.abs(value)
    val pattern = if (abs % 1.0 == 0.0 || currency.digits == 0) "#,##0"
    else "#,##0." + "0".repeat(currency.digits)
    return DecimalFormat(pattern).format(abs) + " " + currency.symbol
}

@Composable
fun money(value: Double): String = formatAmount(value, LocalCurrency.current)

fun formatDate(millis: Long): String =
    SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(millis))

@Composable
fun Avatar(name: String, size: Dp = 48.dp) {
    val brush = AppColors.avatarBrushes[kotlin.math.abs(name.hashCode()) % AppColors.avatarBrushes.size]
    Box(
        modifier = Modifier.size(size).clip(CircleShape).background(brush),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = name.trim().take(1).uppercase(),
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.42f).sp
        )
    }
}

@Composable
fun ProgressPill(progress: Float, brush: Brush, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(RoundedCornerShape(50))
            .background(Color(0x1FFFFFFF))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(progress.coerceIn(0.02f, 1f))
                .height(8.dp)
                .clip(RoundedCornerShape(50))
                .background(brush)
        )
    }
}

fun Modifier.glassCard(radius: Dp = 28.dp): Modifier = this
    .clip(RoundedCornerShape(radius))
    .background(AppColors.Surface)
    .border(1.dp, AppColors.Border, RoundedCornerShape(radius))
