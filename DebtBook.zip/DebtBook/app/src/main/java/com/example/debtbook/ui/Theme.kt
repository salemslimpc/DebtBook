package com.example.debtbook.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Typography

object AppColors {
    val Bg = Color(0xFF0B0F1A)
    val Surface = Color(0xFF141A2B)
    val SurfaceHigh = Color(0xFF1C2440)
    val Border = Color(0x1FFFFFFF)
    val TextPrimary = Color(0xFFF4F6FF)
    val TextSecondary = Color(0xFF9AA3C2)

    val Mint = Color(0xFF2EE6A6)      // لي
    val Coral = Color(0xFFFF5C7A)     // عليّ
    val Violet = Color(0xFF7C5CFF)
    val Cyan = Color(0xFF35C7FF)

    val HeroBrush = Brush.linearGradient(listOf(Color(0xFF7C5CFF), Color(0xFF35C7FF)))
    val MintBrush = Brush.linearGradient(listOf(Color(0xFF2EE6A6), Color(0xFF1FB6C9)))
    val CoralBrush = Brush.linearGradient(listOf(Color(0xFFFF5C7A), Color(0xFFFF9A5C)))

    val avatarBrushes = listOf(
        Brush.linearGradient(listOf(Color(0xFF7C5CFF), Color(0xFFB57CFF))),
        Brush.linearGradient(listOf(Color(0xFF35C7FF), Color(0xFF2E7CFF))),
        Brush.linearGradient(listOf(Color(0xFF2EE6A6), Color(0xFF1FB6C9))),
        Brush.linearGradient(listOf(Color(0xFFFF5C7A), Color(0xFFFF9A5C))),
        Brush.linearGradient(listOf(Color(0xFFFFC857), Color(0xFFFF8F5C)))
    )
}

private val DarkScheme = darkColorScheme(
    primary = AppColors.Violet,
    secondary = AppColors.Mint,
    tertiary = AppColors.Coral,
    background = AppColors.Bg,
    surface = AppColors.Surface,
    surfaceVariant = AppColors.SurfaceHigh,
    onPrimary = Color.White,
    onBackground = AppColors.TextPrimary,
    onSurface = AppColors.TextPrimary,
    onSurfaceVariant = AppColors.TextSecondary,
    outline = AppColors.Border
)

private val AppTypography = Typography(
    displayLarge = TextStyle(fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = (-1).sp),
    headlineMedium = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp),
    bodyMedium = TextStyle(fontSize = 14.sp),
    labelMedium = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Medium)
)

/** التطبيق داكن دائماً لأنه جزء من هويته البصرية. */
@Composable
fun DebtBookTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, typography = AppTypography, content = content)
}
