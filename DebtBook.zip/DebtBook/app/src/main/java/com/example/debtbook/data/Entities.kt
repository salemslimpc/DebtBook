package com.example.debtbook.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "persons")
data class Person(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis()
)

/** isOwedToMe = true  -> الشخص مدين لي.  false -> أنا مدين للشخص. */
@Entity(
    tableName = "debts",
    foreignKeys = [ForeignKey(
        entity = Person::class,
        parentColumns = ["id"],
        childColumns = ["personId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("personId")]
)
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long,
    val amount: Double,
    val isOwedToMe: Boolean,
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val dueDate: Long? = null
)

@Entity(
    tableName = "payments",
    foreignKeys = [ForeignKey(
        entity = Debt::class,
        parentColumns = ["id"],
        childColumns = ["debtId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("debtId")]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val debtId: Long,
    val amount: Double,
    val paidAt: Long = System.currentTimeMillis()
)
