package com.example.debtbook.data

import java.text.Collator
import java.util.Currency
import java.util.Locale

data class CountryOption(
    val iso: String,
    val name: String,
    val currencyCode: String,
    val currencyName: String
)

data class CurrencyInfo(val code: String, val symbol: String, val digits: Int)

object Countries {
    /** Countries not offered in the app. */
    private val EXCLUDED = setOf("IL")

    /**
     * Every ISO 3166 country/region that has an official currency, named in the active language.
     * Names and currencies come from the system's locale data, so each country gets its own
     * official currency automatically.
     */
    fun list(locale: Locale = Locale.getDefault()): List<CountryOption> {
        val collator = Collator.getInstance(locale)
        return Locale.getISOCountries()
            .filter { it !in EXCLUDED }
            .mapNotNull { iso ->
                val region = Locale.Builder().setRegion(iso).build()
                val cur = runCatching { Currency.getInstance(region) }.getOrNull()
                    ?: return@mapNotNull null
                if (cur.currencyCode == "XXX") return@mapNotNull null
                val name = region.getDisplayCountry(locale)
                if (name.isBlank() || name == iso) return@mapNotNull null
                CountryOption(iso, name, cur.currencyCode, cur.getDisplayName(locale))
            }
            .sortedWith { a, b -> collator.compare(a.name, b.name) }
    }

    fun currencyInfo(code: String, locale: Locale = Locale.getDefault()): CurrencyInfo {
        val c = Currency.getInstance(code)
        return CurrencyInfo(code, c.getSymbol(locale), c.defaultFractionDigits.coerceAtLeast(0))
    }

    fun flagEmoji(iso: String): String =
        iso.uppercase().map { String(Character.toChars(0x1F1E6 + (it - 'A'))) }.joinToString("")
}
