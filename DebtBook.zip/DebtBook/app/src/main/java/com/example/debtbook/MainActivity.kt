package com.example.debtbook

import android.os.Bundle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.debtbook.data.Countries
import com.example.debtbook.data.Prefs
import com.example.debtbook.ui.AddDebtSheet
import com.example.debtbook.ui.CountryScreen
import com.example.debtbook.ui.DebtBookTheme
import com.example.debtbook.ui.HomeScreen
import com.example.debtbook.ui.LanguageDialog
import com.example.debtbook.ui.LocalCurrency
import com.example.debtbook.ui.PersonScreen
import com.google.android.gms.ads.MobileAds
import com.google.android.ump.ConsentRequestParameters
import com.google.android.ump.UserMessagingPlatform
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private val vm: DebtViewModel by viewModels()
    private val prefs by lazy { Prefs(this) }

    private var adsReady by mutableStateOf(false)
    private val adsStarted = AtomicBoolean(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setupAds()
        setContent {
            // Layout direction follows the active language (RTL for Arabic) automatically.
            DebtBookTheme {
                val state by vm.state.collectAsStateWithLifecycle()
                var selectedId by remember { mutableStateOf<Long?>(null) }
                var showAdd by remember { mutableStateOf(false) }
                var showLanguage by remember { mutableStateOf(false) }
                var showCountry by remember { mutableStateOf(false) }
                var countryIso by remember { mutableStateOf(prefs.countryIso) }
                var currencyCode by remember { mutableStateOf(prefs.currencyCode) }
                val currencyInfo = remember(currencyCode) {
                    currencyCode?.let { Countries.currencyInfo(it) }
                }

                val selected = state.people.firstOrNull { it.person.id == selectedId }
                if (selectedId != null && selected == null) selectedId = null

                BackHandler(enabled = showCountry && currencyInfo != null) { showCountry = false }
                BackHandler(enabled = !showCountry && selected != null) { selectedId = null }

                if (currencyInfo == null || showCountry) {
                    // First launch: the country decides the default currency.
                    CountryScreen(
                        initialIso = countryIso,
                        onBack = if (currencyInfo != null) ({ showCountry = false }) else null,
                        onConfirm = { c ->
                            prefs.countryIso = c.iso
                            prefs.currencyCode = c.currencyCode
                            countryIso = c.iso
                            currencyCode = c.currencyCode
                            showCountry = false
                        }
                    )
                } else {
                    CompositionLocalProvider(LocalCurrency provides currencyInfo) {
                        if (selected == null) {
                            HomeScreen(
                                state = state,
                                onPersonClick = { selectedId = it },
                                onAddClick = { showAdd = true },
                                onLanguageClick = { showLanguage = true },
                                onCountryClick = { showCountry = true },
                                showAds = adsReady
                            )
                        } else {
                            PersonScreen(
                                summary = selected,
                                onBack = { selectedId = null },
                                onAddPayment = vm::addPayment,
                                onDeleteDebt = vm::deleteDebt
                            )
                        }

                        if (showAdd) {
                            AddDebtSheet(
                                knownNames = state.people.map { it.person.name },
                                onDismiss = { showAdd = false },
                                onSave = vm::addDebt
                            )
                        }
                        if (showLanguage) {
                            LanguageDialog(onDismiss = { showLanguage = false })
                        }
                    }
                }
            }
        }
    }

    /** Ask for consent first (required in the EU/UK), then initialise the Ads SDK. */
    private fun setupAds() {
        val consent = UserMessagingPlatform.getConsentInformation(this)
        consent.requestConsentInfoUpdate(
            this,
            ConsentRequestParameters.Builder().build(),
            {
                UserMessagingPlatform.loadAndShowConsentFormIfRequired(this) {
                    if (consent.canRequestAds()) startAds()
                }
            },
            { if (consent.canRequestAds()) startAds() }
        )
        if (consent.canRequestAds()) startAds()
    }

    private fun startAds() {
        if (!adsStarted.compareAndSet(false, true)) return
        MobileAds.initialize(this) { adsReady = true }
    }
}
