package com.example.debtbook.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.res.stringResource
import com.example.debtbook.R
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val DAY = 24L * 60 * 60 * 1000

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDebtSheet(
    knownNames: List<String>,
    onDismiss: () -> Unit,
    onSave: (name: String, amount: Double, isOwedToMe: Boolean, note: String, dueDate: Long?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var owedToMe by remember { mutableStateOf(true) }
    var dueDays by remember { mutableStateOf<Int?>(null) }

    val amount = amountText.replace(',', '.').toDoubleOrNull()
    val canSave = name.isNotBlank() && amount != null && amount > 0

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = AppColors.Surface,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    ) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .navigationBarsPadding()
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(stringResource(R.string.new_debt), color = AppColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)

            // اختيار النوع
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(AppColors.Bg).padding(4.dp)
            ) {
                TypeTab(stringResource(R.string.owed_to_me), owedToMe, AppColors.MintBrush, Modifier.weight(1f)) { owedToMe = true }
                TypeTab(stringResource(R.string.i_owe), !owedToMe, AppColors.CoralBrush, Modifier.weight(1f)) { owedToMe = false }
            }

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(stringResource(R.string.person_name)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            if (knownNames.isNotEmpty()) {
                Row(
                    Modifier.verticalScrollSafeRow(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    knownNames.take(4).forEach { n -> Chip(n, name == n) { name = n } }
                }
            }

            OutlinedTextField(
                value = amountText,
                onValueChange = { amountText = it },
                label = { Text(stringResource(R.string.amount_with_currency, LocalCurrency.current.symbol)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text(stringResource(R.string.note_optional)) },
                modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.due_date), color = AppColors.TextSecondary, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip(stringResource(R.string.due_none), dueDays == null) { dueDays = null }
                Chip(stringResource(R.string.due_week), dueDays == 7) { dueDays = 7 }
                Chip(stringResource(R.string.due_month), dueDays == 30) { dueDays = 30 }
                Chip(stringResource(R.string.due_3months), dueDays == 90) { dueDays = 90 }
            }

            Spacer(Modifier.height(4.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        if (canSave) AppColors.HeroBrush
                        else Brush.linearGradient(listOf(Color(0xFF2A3150), Color(0xFF2A3150)))
                    )
                    .clickable(enabled = canSave) {
                        val due = dueDays?.let { System.currentTimeMillis() + it * DAY }
                        onSave(name, amount!!, owedToMe, note, due)
                        onDismiss()
                    }
                    .padding(vertical = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(stringResource(R.string.save), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
private fun TypeTab(label: String, selected: Boolean, brush: Brush, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .clip(RoundedCornerShape(16.dp))
            .then(if (selected) Modifier.background(brush) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Color.White else AppColors.TextSecondary,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) AppColors.Violet else Color(0x14FFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(label, color = Color.White, fontSize = 13.sp)
    }
}

// صف الاقتراحات: مجرد Modifier فارغ؛ العدد محدود بـ 4 فلا حاجة للتمرير.
private fun Modifier.verticalScrollSafeRow(): Modifier = this
